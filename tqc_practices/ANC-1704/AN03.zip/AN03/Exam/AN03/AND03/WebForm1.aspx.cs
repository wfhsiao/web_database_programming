﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None; // 設定驗證控制項使用傳統驗證方法
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        // TODO: 將賀卡資料寫入資料庫        
        
        
    }
}