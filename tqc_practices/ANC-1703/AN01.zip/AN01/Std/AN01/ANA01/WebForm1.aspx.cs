﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnReset_Click(Object sender, EventArgs e)
    {
        // 重設成預設值
        // 設定文字方塊 = 0, 核取方塊 = false
        chkItem1.Checked = false;
        chkItem2.Checked = false;
        chkItem3.Checked = false;
        chkItem4.Checked = false;
        tbxItem1.Text = "0";
        tbxItem2.Text = "0";
        tbxItem3.Text = "0";
        tbxItem4.Text = "0";
    }

}