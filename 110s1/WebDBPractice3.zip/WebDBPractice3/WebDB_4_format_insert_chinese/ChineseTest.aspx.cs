﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ChineseTest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string ch = chinese.Value;
        string en = english.Value;
        string sql = string.Format($"insert into [chinese] values (N'{ch}', '{en}')");

        try
        {
            SqlDataSource1.InsertCommand = sql;
            SqlDataSource1.Insert();
        }
        catch (Exception ex)
        {
            Response.Output.Write($"error: {ex.Message}, sql={sql}");
        }
        chinese.Value = "";
        english.Value = "";
        chinese.Focus();
    }
}