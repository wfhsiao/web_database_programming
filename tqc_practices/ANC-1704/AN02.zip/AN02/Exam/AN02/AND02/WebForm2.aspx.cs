﻿using System;


public partial class WebForm2 : System.Web.UI.Page
{
    string dateNow = DateTime.Now.ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        // TODO: 請撰寫處理
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        // TODO: 請撰寫儲存成Cookie的處理
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        // TODO: 請撰寫處理
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        // TODO: 請撰寫處理
    }
}