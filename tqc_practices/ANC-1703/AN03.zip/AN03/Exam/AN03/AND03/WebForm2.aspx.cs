﻿using System;


public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    // 計算指定部落格的回應數
    public int numOfComments(string postid)
    {


    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/WebForm1.aspx");
    }
}