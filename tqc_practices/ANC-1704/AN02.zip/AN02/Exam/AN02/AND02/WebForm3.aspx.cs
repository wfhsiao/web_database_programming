﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm3 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // TODO: 請撰寫處理
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        // TODO: 請撰寫刪除Cookie的處理        
    }
}