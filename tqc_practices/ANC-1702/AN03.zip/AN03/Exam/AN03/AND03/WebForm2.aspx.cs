﻿using System;
using System.Linq;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void DetailsView1_DataBound(object sender, EventArgs e)
    {
        if (DetailsView1.Rows.Count == 0)
        {
            DetailsView1.ChangeMode(DetailsViewMode.Insert);
        }
    }
}