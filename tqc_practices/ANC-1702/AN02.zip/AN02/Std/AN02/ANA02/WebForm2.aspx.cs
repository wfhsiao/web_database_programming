﻿using System;
using System.Web.UI;


public partial class WebForm2 : System.Web.UI.Page
{
    string Ans1;

    protected void Page_Load(object sender, EventArgs e)
    {
        Ans1 = Request.QueryString["Q1"];
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string Ans2 = Q2.SelectedValue;
            DateTime dtDay = DateTime.Today.AddDays(10);
            Response.Cookies["Q1"].Value = Ans1;
            Response.Cookies["Q1"].Expires = dtDay;
            Response.Cookies["Q2"].Value = Ans2;
            Response.Cookies["Q2"].Expires = dtDay;
            Response.Redirect("WebForm3.aspx");
        }
    }
}