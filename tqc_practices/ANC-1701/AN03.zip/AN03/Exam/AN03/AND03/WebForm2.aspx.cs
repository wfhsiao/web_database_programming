﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string bookID = Request.QueryString["Id"]; // 取得書號
                                                   // 建立Cookie儲存選購商品
        if (Request.Cookies["Book" + bookID] != null)
        {
            // 存在, 更新數量

        }
        else
        {
            // 不存在, 建立新Cookie

        }
        Response.Cookies["Book" + bookID].Expires = DateTime.Today.AddDays(10);
        Response.Redirect("WebForm3.aspx"); // 轉址至購物車
    }
}
