﻿using System;


public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 設定驗證控制項使用傳統驗證方法

        // TODO: 請撰寫處理
    }    
}