﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        // 根據網址後方的ID來判別要讀取哪本書
        try
        {
            // 宣告變數存放書籍ID，同時也避免直接將奇怪的值直接放進SQL命令
            int id = Convert.ToInt32(Request.QueryString["Id"].ToString());
            // SQL查詢命令
            string sqlSelect = "SELECT * FROM Book WHERE Id=" + id.ToString();

            try
            {
                using (SqlConnection sqlConn =
                 new SqlConnection(WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    // 宣告命令物件
                    SqlCommand sqlCmd = new SqlCommand(sqlSelect, sqlConn);
                    // 開啟資料庫連線
                    sqlConn.Open();

                    // 使用SqlDataReader存放查詢到的資料
                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        if (dr.HasRows)  // 如果查詢結果至少有一筆以上(本例只會傳回1筆)
                        {
                            dr.Read(); // 讀資料

                            // 把資料放進對應的欄位中
                            lblBookName.Text = dr.GetString(1);
                            lblAuthor.Text = dr.GetString(3);
                            lblPublisher.Text = dr.GetString(2);
                            lblPrice.Text = dr.GetInt32(4).ToString();
                            lblISBN.Text = dr.GetString(5);

                            // 釋放物件
                            sqlCmd.Cancel();
                            dr.Close();
                        }
                        else
                        {
                            // ID參數錯誤時
                            lblError.Text = "找不到書籍資料";
                            lblError.Visible = true;
                            result.Visible = false;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // 錯誤處理                 
                lblError.Text = "請檢查資料庫連接或程式是否有問題";
                lblError.Visible = true;
                result.Visible = false;
            }

        }
        catch (Exception)
        {
            // 直接進入WebForm3.aspx或網址後方並未有ID參數時
            lblError.Text = "非法存取";
            lblError.Visible = true;
            result.Visible = false;
        }
    }
}