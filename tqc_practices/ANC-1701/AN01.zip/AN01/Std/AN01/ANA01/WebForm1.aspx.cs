﻿using System;


public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        double total = 0.0;
        int mqty, dqty;
        mqty = Convert.ToInt32(txtMQty.Text);
        dqty = Convert.ToInt32(txtDQty.Text);
        if (rdbsw.Checked)
        {
            total += 30 * mqty;
        }
        if (rdbhb.Checked)
        {
            total += 40 * mqty;
        }
        if (rdbBean.Checked)
        {
            total += 20 * dqty;
        }
        if (rdbTea.Checked)
        {
            total += 25 * dqty;
            if (chkPearl.Checked)
                total += 5 * dqty;
        }
        if (rdbBean.Checked && chkPearl.Checked)
        {
            lblOutput.Text = "錯誤！豆漿不能加珍珠";
        }
        else
            lblOutput.Text = txtName.Text + " 的費用是：" + total.ToString("C");
    }
}
