﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 根據網址後方的CardID來判別要讀取哪張賀卡
        try
        {
            // 宣告變數存放賀卡ID，同時也避免直接將奇怪的值直接放進SQL命令
            int cardID = Convert.ToInt32(Request.QueryString["CardID"].ToString());
            // SQL查詢命令
            string sqlSelect = "SELECT * FROM PostCard WHERE CardID=" + cardID.ToString();
            
            try
            {
                using (SqlConnection sqlConn =
                 new SqlConnection(WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    // 宣告命令物件
                    SqlCommand sqlCmd = new SqlCommand(sqlSelect, sqlConn);
                    // 開啟資料庫連線
                    sqlConn.Open();

                    // 使用SqlDataReader存放查詢到的資料
                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        if (dr.HasRows)  // 如果查詢結果至少有一筆以上(本例只會傳回1筆)
                        {
                            dr.Read(); // 讀資料

                            // 把資料放進對應的欄位中
                            lblDate.Text = dr.GetDateTime(7).ToString();
                            lblSender.Text = dr.GetString(1);
                            lblReceiver.Text = dr.GetString(4);
                            lblMessage.Text = dr.GetString(3);
                            imgCard.ImageUrl = "IMAGES/" + dr.GetString(6);

                            // 釋放物件
                            sqlCmd.Cancel();
                            dr.Close();
                        }
                        else
                        {
                            // CrdID參數錯誤時
                            msg.Text = "找不到賀卡資料";
                            show.Visible = false;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // 錯誤處理
                msg.Text = "請檢查資料庫連接是否有問題";
                show.Visible = false;
            }
            
        }
        catch (Exception)
        {
            // 直接進入WebForm3.aspx或網址後方並未有CardID參數時
            msg.Text = "非法存取";
            show.Visible = false;
        }
        
    }
}