﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class WebForm1 : System.Web.UI.Page
{
    private DataSet objDS;
    private SqlDataAdapter objAdapter;
    private DataTable appTable;
    // 資料庫連接字串
    private string strDbCon;
        protected void Page_Load(object sender, EventArgs e)
    {
        strDbCon = "Data Source=(LocalDB)\\MSSQLLocalDB;" +
                                 "AttachDbFilename=" +
                                 Server.MapPath("App_Data\\Appointment.mdf") +
                                 ";Integrated Security=True";
        string strSQL;
        
        lblMessage.Text = "診所的所有預約資訊";
        // 建立Connection物件
        // 開啟資料連接
        // 建立DataSet物件
        // 建立DataAdapter物件
        // 填入DataSet物件
        // 取得所有預約資料的DataTable物件
        // 是否是表單送回
        if (!IsPostBack)
        {
            // 填入病人資料
            DateTime selectedDate = DateTime.Now;
            // 呼叫getFreeDate(selectedDate)取得可用日期
        }
        else
        {
            // 執行資料繫結
        }
        // 關閉資料連接
    }
    // 填入病人資料
    void FillPatientInfo()
    {

    }
    // 取得可用的日期
    DateTime getFreeDate(DateTime selectedDate)
    {
        if (appTable.Rows.Count > 0)   // DataTable物件是否有預約記錄
        {
            DateTime tDate;
            Boolean isOKDate = false;
            while (!isOKDate)
            {
                isOKDate = true;
                // 取出所有預約記錄來檢查日期是否已預約
                foreach (DataRow tRow in appTable.Rows)
                {
                    tDate = Convert.ToDateTime(tRow["DateOfAptment"]);
                    if (tDate.Date == selectedDate.Date)
                    {
                        isOKDate = false;
                        // 可預約日是下一天
                        selectedDate = selectedDate.AddDays(1);
                    }
                }
            }
        }
        return selectedDate;
    }

    protected void calDentist_DayRender(object sender, DayRenderEventArgs e)
    {
        if (appTable.Rows.Count > 0)   // DataTable物件是否有預約記錄
        {
            DateTime tDate;
            // 檢查已預約日期, 以便在Calendar控制項顯示此日為有預約
            foreach (DataRow tRow in appTable.Rows)
            {
                // 指定背景色彩
                // 建立Label控制項顯示 "<br/>有預約!"

            }
        }
    }

    protected void calDentist_SelectionChanged(object sender, EventArgs e)
    {

        // 建立可用時間的下拉式清單項目

    }

    protected void ddlPatient_SelectedIndexChanged(object sender, EventArgs e)
    {
        // 取得選擇的病人資料            




        // 顯示病人資料



    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        // 新增預約記錄
    }

    protected void viewAp_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        Response.Redirect("WebForm1.aspx");
    }
}