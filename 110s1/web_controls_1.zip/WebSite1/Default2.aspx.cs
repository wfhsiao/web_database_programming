﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int coverprice = 0;
        if (cbEng_cover.Checked)
        {
            if (! rbEng_paper.Checked)
            {
                msg.Text = "Error! 只有英文平裝書可加購書套";
                return;
            }
            else
            {
                coverprice = Convert.ToInt32(Regex.Match(cbEng_cover.Text, @"-?\d+").Value);
            }
        }

        int cal_amt = Convert.ToInt32(txtCal_amt.Text);
        int eng_amt = Convert.ToInt32(txtEng_amt.Text);
        int total = 0;
        if (rbCal_paper.Checked)
        {
            string price = Regex.Match(rbCal_paper.Text, @"-?\d+").Value;
            total += cal_amt * Convert.ToInt32(price);
        }
        if (rbCal_hard.Checked)
        {
            string price = Regex.Match(rbCal_hard.Text, @"-?\d+").Value;
            total += cal_amt * Convert.ToInt32(price);
        }
        if (rbEng_paper.Checked)
        {
            string price = Regex.Match(rbEng_paper.Text, @"-?\d+").Value;
            total += eng_amt * (Convert.ToInt32(price)+ coverprice);
        }
        if (rbEng_hard.Checked)
        {
            string price = Regex.Match(rbEng_hard.Text, @"-?\d+").Value;
            total += eng_amt * Convert.ToInt32(price);
        }

        msg.Text = string.Format("{0}你的購買總額是{1}元。", txtName.Text, total);
    }
}