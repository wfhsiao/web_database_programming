﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PlayCards2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }



    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            SqlDataSource1.SelectParameters["point"].DefaultValue = "%";
            SqlDataSource1.SelectParameters["shape"].DefaultValue = "%";
        }
        DataView dv = (DataView)SqlDataSource1.Select(new DataSourceSelectArguments());
        Literal1.Text = "符合上面條件的資料共有: " + dv.Count + " 筆.";

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string[] shapes = { "s", "h", "d", "c" };
        string[] points = { "a", "2", "3", "4", "5", "6", "7", "8", "9", "t", "j", "q", "k" };
        string insert_sql = "insert into [playcards]([shape], [point]) values";
        string sql = "";
        foreach (string s in shapes)
        {
            foreach (string p in points)
            {
                if (sql == "")
                    sql = insert_sql;
                else
                    sql += ",\n";
                sql += string.Format("('{0}', '{1}')", s, p);
            }
        }

        try
        {
            SqlDataSource1.InsertCommand = sql;
            SqlDataSource1.Insert();
        }
        catch (Exception ex)
        {
            Response.Output.Write("insertion error: {0}, sql={1}", ex.Message, sql);
        }

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlDataSource1.DeleteCommand = "delete from [playcards]";
        SqlDataSource1.Delete();
    }

    protected void ChkRow_CheckedChanged1(object sender, EventArgs e)
    {
        CheckBox chkstatus = (CheckBox)sender;
        GridViewRow row = (GridViewRow)chkstatus.NamingContainer;
        GridView1.SelectedIndex = row.DataItemIndex % GridView1.PageSize;
    }

    protected void ChkHeader_CheckedChanged1(object sender, EventArgs e)
    {
        CheckBox chkheader = (CheckBox)GridView1.HeaderRow.FindControl("ChkHeader");
        foreach (GridViewRow row in GridView1.Rows)
        {
            CheckBox chkrow = (CheckBox)row.FindControl("ChkRow");
            chkrow.Checked = chkheader.Checked;
        }
        if (chkheader.Checked)
            GridView1.SelectedIndex = 0;
        else
            GridView1.SelectedIndex = -1;
    }

    protected void GridView1_PageIndexChanged(object sender, EventArgs e)
    {
        GridView1.SelectedIndex = -1;
    }
}