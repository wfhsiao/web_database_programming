﻿using System;

public partial class WebForm1 : System.Web.UI.Page
{
    /* TODO: 完成題目要求所需功能 */

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    // 顯示聊天訊息
    public void ShowMessage()
    {
        lblOutput.Text = Application["Msg9"] + "<br/>";
        lblOutput.Text += Application["Msg8"] + "<br/>";
        lblOutput.Text += Application["Msg7"] + "<br/>";
        lblOutput.Text += Application["Msg6"] + "<br/>";
        lblOutput.Text += Application["Msg5"] + "<br/>";
        lblOutput.Text += Application["Msg4"] + "<br/>";
        lblOutput.Text += Application["Msg3"] + "<br/>";
        lblOutput.Text += Application["Msg2"] + "<br/>";
        lblOutput.Text += Application["Msg1"] + "<br/>";
    }
}
