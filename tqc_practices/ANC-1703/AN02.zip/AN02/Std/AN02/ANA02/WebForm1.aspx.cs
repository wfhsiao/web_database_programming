﻿using System;


public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int no = ddlProduct.SelectedIndex;
        // 建立選購商品的Cookie
        Response.Cookies["Item" + no]["No"] = Convert.ToString(no);
        Response.Cookies["Item" + no]["Quantity"] = txtQuantity.Text;
        Response.Cookies["Item" + no]["Name"] = Server.UrlEncode(ddlProduct.SelectedItem.ToString());
        Response.Cookies["Item" + no]["Price"] = ddlProduct.SelectedValue;
        lblOutput.Text = "已經成功新增項目至購物車...";
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm2.aspx");
    }
}
