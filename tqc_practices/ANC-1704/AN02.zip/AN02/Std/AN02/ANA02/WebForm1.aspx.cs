﻿using System;
using System.Web.UI;


public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None; // 設定驗證控制項使用傳統驗證方法

        if (IsPostBack)
        {
            // 修改Session變數儲存調查表資料
            if (rb1.Checked)
            {
                Session["img"] = "img01.gif";
            }
            else if (rb2.Checked)
            {
                Session["img"] = "img02.gif";
            }
            else if (rb2.Checked)
            {
                Session["img"] = "img03.gif";
            }
            else
            {
                Session["img"] = "img04.gif";
            }

            Session["receiver"] = receiver.Text;
            Session["sender"] = sender1.Text;
            Session["message"] = message.Text;

            // 轉向到WebForm2.aspx
            Response.Redirect("WebForm2.aspx");
        }
        else
        {
            // 如果先前有建立Session，則回存到表單
            if (Page.Session.Count > 0)
            {
                // 回存使用者所選擇的圖片
                try
                {
                    if (Page.Session["img"].ToString().Equals("img01.gif"))
                    {
                        rb1.Checked = true;
                    }
                    else if (Page.Session["img"].ToString().Equals("img02.gif"))
                    {
                        rb2.Checked = true;
                    }
                    else if (Page.Session["img"].ToString().Equals("img03.gif"))
                    {
                        rb3.Checked = true;
                    }
                    else
                    {
                        rb4.Checked = true;
                    }
                }
                catch (Exception)
                {
                    rb1.Checked = true;
                }

                // 回存收件人資料
                try
                {
                    receiver.Text = Page.Session["receiver"].ToString();
                }
                catch (Exception)
                {
                    receiver.Text = "";
                }

                // 回存寄件人資料
                try
                {
                    sender1.Text = Page.Session["sender"].ToString();
                }
                catch (Exception)
                {
                    sender1.Text = "";
                }

                // 回存訊息資料
                try
                {
                    message.Text = Page.Session["message"].ToString();
                }
                catch (Exception)
                {
                    message.Text = "";
                }
            }
        }
    }
}