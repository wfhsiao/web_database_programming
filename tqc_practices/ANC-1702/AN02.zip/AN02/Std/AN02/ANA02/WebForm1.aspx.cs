﻿using System;
using System.Web.UI;


public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string Ans1 = Q1.SelectedValue;
            Response.Redirect("WebForm2.aspx?Q1=" + Ans1);
        }
    }
}
