﻿using System;

public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /* TODO: 請完成刪除指定Cookie的功能 */
    }
}
