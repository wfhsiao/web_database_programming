﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    DropDownList ddl = new DropDownList();
    protected void Page_Load(object sender, EventArgs e)
    {
        ddl = new DropDownList();
        Button btn = new Button();
        btn.Text = "OK";
        btn.Click += new System.EventHandler(this.ddl_SelectedIndexChanged);
        div1.Controls.Add(ddl);
        div1.Controls.Add(btn);
        ddl.DataSource = new string[] { "red", "orange", "yellow" };
        ddl.DataBind();
        //ddl.Items.Insert(0, "choose a color");
        //ddl.AutoPostBack = true;
        //ddl.SelectedIndexChanged += new System.EventHandler(this.ddl_SelectedIndexChanged);
        if (! IsPostBack)
        {
            string[] eng = { "heady", "invariably", "illiterate", "lavish", "incessant", "lethal", "incumbent", "lucrative", "indignant", "ludicrous", "inherent", "malicious", "initial", "mock", "integral", "mundane", "intricate", "optional", "invalid", "perennial" };
            string chiString = "飄飄然的, 必定地不變地, 不識字的, 鋪張的奢華的, 不停的, 致命的, 現職的, 可獲利的, 憤憤不平的, 可笑的滑稽的, 固有的, 懷惡意的, 首度的, 煞有其事的, 必須的不可或缺的, 世俗的, 複雜的, 可選擇的, 無效的作廢的, 長期間持續的";
            string[] chi = chiString.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < eng.Length; i++)
            {
                DropDownList1.Items.Add(new ListItem(eng[i], chi[i]));
                BulletedList1.Items.Add(new ListItem(eng[i], string.Format("https://tw.dictionary.search.yahoo.com/search?p={0}", eng[i])));

            }
            DropDownList1.Items.Insert(0, new ListItem("請選擇單字", ""));
            lbFamiliar.DataSource = eng;
            lbFamiliar.DataBind();
        }
    }

    protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
    {
        //DropDownList ddl = (DropDownList) sender;
        Response.Output.Write("You choose {0}", ddl.SelectedValue);
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Response.Output.Write("{0}的中文是{1}", DropDownList1.SelectedItem.Text, DropDownList1.SelectedValue);
    Response.Redirect(string.Format("https://tw.dictionary.search.yahoo.com/search?p={0}", DropDownList1.SelectedItem.Text));
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < lbFamiliar.Items.Count; i++)
        {
            if (lbFamiliar.Items[i].Selected) lbUnFamiliar.Items.Add(lbFamiliar.Items[i]);
        }

        for (int i = lbFamiliar.Items.Count - 1; i >= 0; i--)
        {
            if (lbFamiliar.Items[i].Selected)
            {
                lbFamiliar.Items[i].Selected = false;
                lbFamiliar.Items.RemoveAt(i);
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < lbUnFamiliar.Items.Count; i++)
        {
            if (lbUnFamiliar.Items[i].Selected) lbFamiliar.Items.Add(lbUnFamiliar.Items[i]);
        }

        for (int i = lbUnFamiliar.Items.Count - 1; i >= 0; i--)
        {
            if (lbUnFamiliar.Items[i].Selected)
            {
                lbUnFamiliar.Items[i].Selected = false;
                lbUnFamiliar.Items.RemoveAt(i);
            }
        }
    }

}