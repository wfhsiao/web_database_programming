﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None; // 設定驗證控制項使用傳統驗證方法

        if (!Page.IsPostBack) {
            // 設定只能顯示表單
            osForm.Visible = true;
            result.Visible = false;
        }
        else {
            // 設定只能顯示預覽畫面
            osForm.Visible = false;
            result.Visible = true;

            DateTime today = DateTime.Today; // 取得今天日期
            string userName = user.Text; // 取得推薦者名稱
            string userJob = dropJob.SelectedValue; // 取得職業
            string userComment = comment.Text;  // 取得意見內容
            string userOS = ""; // 宣告存放使用者選擇的作業系統名稱

            // 判斷使用者選擇哪一個作業系統
            if (android.Checked) {
                userOS = android.Text;
            }
            if (ios.Checked) {
                userOS = ios.Text;
            }
            if (windows.Checked) {
                userOS = windows.Text;
            }

            // 如果使用者沒有選擇
            if (userOS.Length == 0) {
                userOS = "使用者沒有選擇作業系統";
                imgOS.Visible = false;
            }

            // 把值放進標籤及圖片裡
            lblDate.Text = today.ToString("yyyy/M/d");
            lblUser.Text = userName;
            lblJob.Text = userJob;
            lblComment.Text = userComment;
            lblOS.Text = userOS;
            imgOS.ImageUrl = "IMAGES/" + userOS + ".png";
        }

    }
}