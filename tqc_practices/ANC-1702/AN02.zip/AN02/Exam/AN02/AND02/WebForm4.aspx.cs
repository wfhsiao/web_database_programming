﻿using System;

public partial class WebForm4 : System.Web.UI.Page
{
    /* TODO: 完成題目要求功能 */

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}