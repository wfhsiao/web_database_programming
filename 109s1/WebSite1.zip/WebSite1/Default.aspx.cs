﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string url = "http://einstein.nptu.edu.tw:9212/sources/datastructure/StudentWebs/data/somewords.csv";
        WebRequest webReq = WebRequest.Create(url);
        WebResponse webRes = webReq.GetResponse();
        Stream webStream = webRes.GetResponseStream();

        TextFieldParser csvParser = new TextFieldParser(webStream, Encoding.GetEncoding("Big5")) //need to refer visual basic
        {
            Delimiters = new string[] { "," },
            TrimWhiteSpace = true
        };
        // skip the header
        //csvParser.ReadLine();
        //int item_field = 1;
        while (!csvParser.EndOfData)
        {
            string[] str = csvParser.ReadFields();

            try
            {
                SqlDataSource2.InsertParameters["word"].DefaultValue = str[0];
                SqlDataSource2.InsertParameters["ch_explanation"].DefaultValue = str[1];
                SqlDataSource2.InsertParameters["rating"].DefaultValue = "0";
                SqlDataSource2.Insert();
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlDataSource2.DeleteCommand = "delete from words2";
        SqlDataSource2.Delete();
    }

    protected void DetailsView1_DataBound(object sender, EventArgs e)
    {
        if (DetailsView1.CurrentMode == DetailsViewMode.Edit)
        {
            if (DetailsView1.DataItem != null)
            {
                DropDownList ddl = (DropDownList)DetailsView1.FindControl("ddlRating");
                ddl.Items.Clear();
                for (int i = 0; i < 11; i++)
                    ddl.Items.Add(i.ToString());
                DataRowView row = (DataRowView)DetailsView1.DataItem;
                ddl.SelectedValue = DataBinder.Eval(row, "rating").ToString();
            }
        }
    }
}