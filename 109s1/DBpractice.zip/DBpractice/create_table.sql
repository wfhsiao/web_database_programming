﻿USE [C:\USERS\USER\DOWNLOADS\DBPRACTICE\APP_DATA\DATABASE.MDF]
GO

/****** Object:  Table [dbo].[keywords2]    Script Date: 2020/11/19 下午 02:49:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[keywords3](
    [id] int primary key not null identity,
	[word] [nvarchar](255) NULL,
	[ch_def] [nvarchar](255) NULL,
	[en_def] [nvarchar](255) NULL
) ON [PRIMARY]
GO

