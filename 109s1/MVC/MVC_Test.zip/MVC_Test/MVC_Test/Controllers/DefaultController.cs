﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Test.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            cl temp = new cl();
            temp.title = "教育程度";
            List<string> ls = new List<string>();
            ls.Add("博士");
            ls.Add("碩士");
            ls.Add("大學");
            ls.Add("高中");
            ls.Add("國中");
            temp.values = ls;
            return View(temp);
        }

        public PartialViewResult show(string input)
        {
            cl temp = new cl();
            temp.title = !string.IsNullOrEmpty(input) && !string.IsNullOrWhiteSpace(input) ? input : string.Empty;

            return PartialView("~/Views/Default/Result.cshtml", temp);
        }
        public class cl
        {
            public string title { get; set; }
            public List<string> values { get; set; }
        }
    }
}