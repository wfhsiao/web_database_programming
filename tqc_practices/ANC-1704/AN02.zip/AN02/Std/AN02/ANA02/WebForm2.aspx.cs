﻿using System;
using System.Web;
using System.Web.UI;


public partial class WebForm2 : System.Web.UI.Page
{
    string dateNow = DateTime.Now.ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        // 如果有傳資料過來，顯示在頁面上
        if (Page.Session.Count > 0)
        {
            // 現在的日期時間
            lblDate.Text = dateNow;

            // 收件人資料
            try
            {
                lblReceiver.Text = Page.Session["receiver"].ToString();
            }
            catch (Exception)
            {
                lblReceiver.Text = "";
            }
            
            // 寄件人資料
            try
            {
                lblSender.Text = Page.Session["sender"].ToString();
            }
            catch (Exception)
            {
                lblSender.Text = "";
            }

            // 訊息資料
            try
            {
                lblMessage.Text = Page.Session["message"].ToString();
            }
            catch (Exception)
            {
                lblMessage.Text = "";
            }

            // 圖片資料
            try
            {
                imgCard.ImageUrl = "IMAGES/" + Page.Session["img"].ToString();
            } catch (Exception)
            {
                imgCard.ImageUrl = "";
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        // 當有Session變數時才把資料儲存成Cookie
        if (Page.Session.Count > 0)
        {
            // 如果有先前建立的Cookie，刪除
            if (Request.Cookies.Count > 0)
            {
                for (int i = 0; i < Request.Cookies.Count; i++)
                {
                    Request.Cookies.Remove(Request.Cookies[i].Name);
                }
            }
            // 宣告Cookie物件
            HttpCookie date = new HttpCookie("date", HttpUtility.UrlEncode(dateNow));
            HttpCookie receiver = new HttpCookie("receiver", HttpUtility.UrlEncode(Page.Session["receiver"].ToString()));
            HttpCookie send = new HttpCookie("sender", HttpUtility.UrlEncode(Page.Session["sender"].ToString()));
            HttpCookie message = new HttpCookie("message", HttpUtility.UrlEncode(Page.Session["message"].ToString()));
            HttpCookie img = new HttpCookie("img", Page.Session["img"].ToString());
            // 設定Cookie過期時間
            date.Expires = DateTime.Now.AddDays(10);
            receiver.Expires = DateTime.Now.AddDays(10);
            send.Expires = DateTime.Now.AddDays(10);
            message.Expires = DateTime.Now.AddDays(10);
            img.Expires = DateTime.Now.AddDays(10);
            // 寫入到Cookie
            Response.Cookies.Add(date);
            Response.Cookies.Add(receiver);
            Response.Cookies.Add(send);
            Response.Cookies.Add(message);
            Response.Cookies.Add(img);
        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm1.aspx");
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm3.aspx");
    }
}