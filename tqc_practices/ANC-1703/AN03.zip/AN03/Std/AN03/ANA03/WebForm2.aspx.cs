﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 是否是表單送回
        if (!IsPostBack)   // 不是
        {
            GridView1.SelectedIndex = 0;
            // 是否有URL參數index, 此為GridView控制項SelectedIndex值
            if (Request.QueryString["index"] != null)
                GridView1.SelectedIndex = Convert.ToInt32(Request.QueryString["index"]);
            GridView1.DataBind();   // 執行資料繫結 
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlDataSource4.Insert();   // 新增回應內容
                                   // 轉址至自己
        Response.Redirect("WebForm2.aspx?blog=" +
                Request.QueryString["blog"] +
                "&index=" + GridView1.SelectedIndex.ToString());
    }
    // 計算指定部落格的回應數
    public int numOfComments(string postid)
    {
        SqlConnection objCon;
        SqlCommand objCmd;
        string strDbCon, strSQL;
        int result;
        // 資料庫連接字串
        strDbCon = "Data Source=(LocalDB)\\MSSQLLocalDB;" +
                   "AttachDbFilename=" +
                   Server.MapPath("App_Data\\Blog.mdf") +
                   ";Integrated Security=True";
        // 使用聚合函數建立查詢回應數的SQL指令
        strSQL = "SELECT Count(*) FROM Comments " +
                  "WHERE postid=" + postid;
        objCon = new SqlConnection(strDbCon);
        objCon.Open();   // 開啟資料庫連接
                         // 建立Command物件的SQL指令
        objCmd = new SqlCommand(strSQL, objCon);
        // 使用ExecuteScalar執行SQL指令
        result = Convert.ToInt32(objCmd.ExecuteScalar());
        objCon.Close();  // 關閉資料庫連接
        return result;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/WebForm1.aspx");
    }
}