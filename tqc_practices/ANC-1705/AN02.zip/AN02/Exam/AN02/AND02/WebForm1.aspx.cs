﻿using System;
using System.Collections.Generic;
// 請引用合適的命名空間
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // TODO: 請撰寫顯示圖片清單的處理
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        // TODO: 請撰寫上傳檔案的處理

        // 如果使用者有選擇檔案的話
        if (FileUpload1.HasFile)
        {
            
        }
        else
        {
            
        }
    }
}