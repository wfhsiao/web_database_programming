﻿using System;
using System.Web;


public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 如果有Cookie的話
        if (Request.Cookies.Count > 0)
        {
            try
            {
                lblDate.Text = HttpUtility.UrlDecode(Request.Cookies["date"].Value);
                lblReceiver.Text = HttpUtility.UrlDecode(Request.Cookies["receiver"].Value);
                lblSender.Text = HttpUtility.UrlDecode(Request.Cookies["sender"].Value);
                lblMessage.Text = HttpUtility.UrlDecode(Request.Cookies["message"].Value);
                imgCard.ImageUrl = "IMAGES/" + Request.Cookies["img"].Value;
            }
            catch (Exception) // 當抓Cookie發現錯誤時
            {
                lblDate.Text = "";
                lblReceiver.Text = "";
                lblSender.Text = "";
                lblMessage.Text = "";
                imgCard.ImageUrl = "";
                msg.Text = "賀卡資料不存在";
                show.Visible = false;
            }
        }
        else // 沒有Cookie時
        {
            msg.Text = "賀卡資料不存在";
            show.Visible = false;
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        // 刪除Cookie
        Response.Cookies["date"].Expires = DateTime.Now.AddDays(-365);
        Response.Cookies["receiver"].Expires = DateTime.Now.AddDays(-365);
        Response.Cookies["sender"].Expires = DateTime.Now.AddDays(-365);
        Response.Cookies["cmessage"].Expires = DateTime.Now.AddDays(-365);
        Response.Cookies["img"].Expires = DateTime.Now.AddDays(-365);
        Response.Redirect("WebForm3.aspx");
    }
}