﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string path = "http://einstein.nptu.edu.tw:9212/sources/ASP.NET/Programs/images/250px-Bisection_method.ver1.png";
        //Response.Output.Write("The filename in '{0}' is '{1}'", path, Path.GetFileName(path));
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("uploads/") + FileUpload1.FileName);
            HyperLink1.Visible = true;
            HyperLink1.Text = FileUpload1.FileName;
            HyperLink1.NavigateUrl = "uploads/" + FileUpload1.FileName;
        }
    }
}