﻿select *
from [keywords]
where [word] = 'this' or [word]='hello'