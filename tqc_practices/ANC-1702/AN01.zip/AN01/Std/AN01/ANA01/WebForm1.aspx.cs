﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            lblOutput.Text = "候選人：" + ddlCandidate.SelectedValue +
                             "<br/>姓名：" + txtName1.Text +
                             "<br/>科系：" + rblDept.SelectedValue +
                             "<br/>年級：" + txtClass.Text +
                             "<br/>電郵：" + txtEmail.Text;
        }
        else
        {
            lblOutput.Text = "請完整輸入表單內容...";
        }
    }

    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (args.Value.StartsWith("F"))
            args.IsValid = true;
        else
            args.IsValid = false;
    }
}
