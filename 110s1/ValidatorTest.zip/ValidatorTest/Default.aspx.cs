﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (! IsPostBack)
        {
            DropDownList1.DataSource = new string[] { "男性", "女性", "中性" };
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("請選擇性別", ""));
        }
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int age = Convert.ToInt32( TextBox2.Text );
        msg.Text = string.Format("{0}您的年齡為{1}，性別為{2}，3年後你是{3}歲。", TextBox1.Text, age, DropDownList1.SelectedValue, age + 3);
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        this.accntMsg.Text = string.Format("<br />您輸人的email是：{0}<br />", TextBox3.Text);
        accntMsg.Text += string.Format("您輸人的簡介是：<br />{0}", TextBox6.Text.Replace("\n", "<br />"));
    }
}