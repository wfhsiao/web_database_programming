﻿using System;
using System.Web.UI;

public partial class WebForm3 : System.Web.UI.Page
{
    string Ans1, Ans2;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["Q1"] != null)
        {
            Ans1 = Request.Cookies["Q1"].Value;
        }
        if (Request.Cookies["Q2"] != null)
        {
            Ans2 = Request.Cookies["Q2"].Value;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string Ans3 = Q3.SelectedValue;
            DateTime dtDay = DateTime.Today.AddDays(10);
            Session["Q1"] = Ans1;
            Session["Q2"] = Ans2;
            Session["Q3"] = Ans3;
            Response.Redirect("WebForm4.aspx");
        }
    }
}
