﻿using System;

public partial class WebForm2 : System.Web.UI.Page
/* TODO: 請完成撰寫題目要求功能 */
{
    protected void Page_Load(object sender, EventArgs e)
    {
    string output = "";
    // 宣告變數

    output += "<table border='1' style='text - align: center'>";
    output += "<tr bgcolor='#DEE8F5'>";
    output += "<th>功能</th><th>商品編號</th><th>商品名稱</th>";
    output += "<th>訂價</th><th>訂購數量</th><th>小計</th></tr>";
    // 顯示多鍵Cookie的購買項目


    output += "<tr><td colspan='5' align='right'>購物車總價：</td>";
    // 顯示總價
    output += "</table>";
    // 在Label控制項顯示購物車表格
    }
}
