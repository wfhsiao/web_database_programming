﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.PreviousPage != null)
        {  // 如果沒有經由WebForm1.aspx送資料過來，則PreviousPage = null
            if (Page.PreviousPage.IsCrossPagePostBack)
            { // 如果PreviousPage.IsCrossPagePostBack == True
                // 宣告變數
                bool[] itemsCheck = new bool[4];  // 用來存放核取方塊的值                
                int[] itemsOrder = new int[4];  // 用來存放餐點數量
                int[] itemsPrice = new int[4];  // 用來存放價格
                string[] itemsTitle = new string[4];  // 用來存放餐點名稱
                int total = 0; // 用來存放總計金額

                for (int i = 0; i < 4; i++)
                {
                    // 讀取核取方塊是否被勾選
                    itemsCheck[i] = ((CheckBox) PreviousPage.Form.FindControl("chkItem" + (i + 1))).Checked;
                    // 讀取數量
                    try
                    {
                        itemsOrder[i] = Convert.ToInt32(((TextBox) PreviousPage.Form.FindControl("tbxItem" + (i + 1))).Text);
                    }
                    catch (Exception)
                    {
                        itemsOrder[i] = 0;  //當錯誤發生時，設為0
                    }
                    // 讀取價格
                    itemsPrice[i] = Convert.ToInt32(((TableCell) PreviousPage.Form.FindControl("price" + (i + 1))).Text);
                    // 讀取餐點名稱
                    itemsTitle[i] = ((TableCell) PreviousPage.Form.FindControl("item" + (i + 1))).Text;
                }

                /* 
                 * 檢查是否被勾選及數量是否大於0
                 * 若符合新增表格列並放置資料及計算小計
                */
                for (int i = 0; i < 4; i++)
                {
                    if (itemsCheck[i] == true && itemsOrder[i] > 0)
                    {
                        // 宣告表格列、儲存格物件
                        TableRow row = new TableRow();
                        TableCell cell1 = new TableCell();
                        TableCell cell2 = new TableCell();
                        TableCell cell3 = new TableCell();
                        TableCell cell4 = new TableCell();

                        // 設定列字型、水平對齊
                        row.Style.Add("font-size", "Large");
                        row.HorizontalAlign = HorizontalAlign.Right;
                        // 設定儲存格框線
                        cell1.BorderStyle = BorderStyle.Solid;
                        cell2.BorderStyle = BorderStyle.Solid;
                        cell3.BorderStyle = BorderStyle.Solid;
                        cell4.BorderStyle = BorderStyle.Solid;

                        // 放資料
                        cell1.Text = itemsTitle[i]; // 餐點名稱                        
                        cell2.Text = itemsOrder[i].ToString(); // 餐點數量
                        cell3.Text = itemsPrice[i].ToString(); // 餐點價格
                        cell4.Text = (itemsOrder[i] * itemsPrice[i]).ToString();  // 餐點小計

                        // 把小計加總到總金額
                        total += itemsOrder[i] * itemsPrice[i];

                        // 把儲存格加入到列
                        row.Cells.Add(cell1);
                        row.Cells.Add(cell2);
                        row.Cells.Add(cell3);
                        row.Cells.Add(cell4);

                        // 把列加入表格
                        resultTable.Rows.Add(row);
                    }
                }

                // 如果總金額>0
                if (total > 0)
                {
                    lblMsg.Visible = true;  // 顯示歡迎訊息
                }
                else
                {
                    btnBack.Visible = true; // 顯示返回按鈕
                }

                // 宣告表格列、儲存格物件
                TableRow rowTotal = new TableRow();
                TableCell cell = new TableCell();

                // 設定儲存格橫跨4欄
                cell.ColumnSpan = 4;
                // 設定儲存格水平靠右對齊
                cell.HorizontalAlign = HorizontalAlign.Right;
                // 設定儲存格框線
                cell.BorderStyle = BorderStyle.Solid;
                // 設定儲存格字型
                cell.Style.Add("font-size", "Large");
                // 放總計金額
                cell.Text = "總計：" + total.ToString();
                // 把儲存格加入列
                rowTotal.Cells.Add(cell);
                // 把列加入表格
                resultTable.Rows.Add(rowTotal);
            }
            else
            {
                Response.Redirect("WebForm1.aspx"); // 跳回到WebForm1.aspx
            }
        }
        else
        {
            Response.Redirect("WebForm1.aspx"); // 跳回到WebForm1.aspx
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm1.aspx"); // 跳回到WebForm1.aspx
    }
}