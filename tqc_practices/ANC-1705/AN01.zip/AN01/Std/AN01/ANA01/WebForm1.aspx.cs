﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        // 重設文字框
        tName.Text = "";
        tEmail.Text = "";
        // 重設飯店選單
        dHotel.SelectedIndex = 0;
        // 重設房型
        rbRoomType.SelectedIndex = 0;
        // 重設入住天數
        cbDays.SelectedIndex = -1;
    }
}