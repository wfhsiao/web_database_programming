﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        // 根據使用者所填寫的欄位選擇適當的SQL查詢指令
        // 1. 只填寫寄件者
        if (receiver.Text.Equals("") && !sender1.Text.Equals(""))
        {
            SqlDataSource1.SelectCommand =
                "SELECT [CardID], [Sender], [Receiver], [PostDate] FROM [PostCard] WHERE [Sender] LIKE N'%' + @Sender + '%' ORDER BY [Sender];";
        }
        // 2. 只填寫收件者
        else if (!receiver.Text.Equals("") && sender1.Text.Equals(""))
        {
            SqlDataSource1.SelectCommand =
               "SELECT [CardID], [Sender], [Receiver], [PostDate] FROM [PostCard] WHERE [Receiver] LIKE N'%' + @Receiver + '%' ORDER BY [Sender];";
        }
        // 3. 兩個都寫或不寫
        else
        {
            SqlDataSource1.SelectCommand =
                "SELECT [CardID], [Sender], [Receiver], [PostDate] FROM [PostCard] WHERE (([Sender] LIKE N'%' + @Sender + '%') AND ([Receiver] LIKE N'%' + @Receiver + '%')) ORDER BY [Sender];";
        }
        
        // GridView控制項重新綁定資料
        result.DataBind();
    }
}