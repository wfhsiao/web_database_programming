﻿using System;


public partial class WebForm4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        decimal correct = 0.0m;
        string Ans1, Ans2, Ans3;
        Ans1 = Session["Q1"].ToString();
        Ans2 = Session["Q2"].ToString();
        Ans3 = Session["Q3"].ToString();
        if (Ans1.Equals("PHP"))
        {
            correct += 1;
        }
        if (Ans2.Equals("JavaScript"))
        {
            correct += 1;
        }
        if (Ans3.Equals("JSP"))
        {
            correct += 1;
        }
        lblOutput.Text = "<b>你的成績 = " + ((100.0m * correct) / 3.0m) + "分</b><br/>" +
                         "Q1-答案：" + Ans1 + " / 正確PHP<br/>" +
                         "Q2-答案：" + Ans2 + " / 正確JavaScript<br/>" +
                         "Q3-答案：" + Ans3 + " / 正確JSP<br/>";
    }
}