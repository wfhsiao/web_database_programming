﻿using System;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string output = "";
        int quantity, price;
        decimal total = 0m;
        output += "<table border='1' style='text - align: center'>";
        output += "<tr bgcolor='#DEE8F5'>";
        output += "<th>功能</th><th>商品編號</th><th>商品名稱</th>";
        output += "<th>訂價</th><th>訂購數量</th><th>小計</th></tr>";
        foreach (string item in Request.Cookies)
        {
            output += "<tr>";
            if (Request.Cookies[item].HasKeys)
            {
                price = Convert.ToInt32(Request.Cookies[item]["Price"]);
                quantity = Convert.ToInt32(Request.Cookies[item]["Quantity"]);
                total += price * quantity;
                output += "<td>";
                output += "<a href='WebForm3.aspx?No=" + item + "'>刪除</a>";
                output += "</td>";
                output += "<td>" + Request.Cookies[item]["No"] + "</td>";
                output += "<td>" + Server.UrlDecode(Request.Cookies[item]["Name"]) + "</td>";
                output += "<td>" + price + "</td>";
                output += "<td>" + quantity + "</td>";
                output += "<td>" + (price * quantity) + "</td>";
            }
            output += "</tr>";
        }

        output += "<tr><td colspan='5' align='right'>購物車總價：</td>";
        output += "<td>" + total + "</td></tr>";
        output += "</table>";
        lblOutput.Text = output;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm1.aspx");
    }
}