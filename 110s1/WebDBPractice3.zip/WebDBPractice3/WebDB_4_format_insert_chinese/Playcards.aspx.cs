﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Playcards : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string[] shapes = { "s", "h", "d", "c" };
        string[] points = { "a", "2", "3", "4", "5", "6", "7", "8", "9", "t", "j", "q", "k" };
        string sql = "insert into [playcards]([shape], [point]) values ";
        for (int s = 0; s < shapes.Length; s++)
        {
            for (int p = 0; p < points.Length; p++)
            {
                string rec;
                if (s==shapes.Length-1 && p==points.Length-1)
                    rec = string.Format($"('{shapes[s]}', '{points[p]}')");
                else
                    rec = string.Format($"('{shapes[s]}', '{points[p]}'), ");
                sql += rec;
            }
        }
        try
        {
            SqlDataSource1.InsertCommand = sql;
            SqlDataSource1.Insert();
        }
        catch (Exception ex)
        {
            Response.Output.Write($"Error: {ex.Message}: {sql}");
        }
        
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlDataSource1.DeleteCommand = "delete from [playcards]";
        SqlDataSource1.Delete();
    }
}