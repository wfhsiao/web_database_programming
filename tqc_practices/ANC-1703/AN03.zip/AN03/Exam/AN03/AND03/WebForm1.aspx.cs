﻿using System;
using System.Data.SqlClient;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    // 計算指定部落格的文章數
    public int numOfPosts(string blogid)
    {
        SqlConnection objCon;
        SqlCommand objCmd;
        string strDbCon, strSQL;
        int result;
        // 資料庫連接字串
        strDbCon = "Data Source=(LocalDB)\\MSSQLLocalDB;" +
                   "AttachDbFilename=" +
                   Server.MapPath("App_Data\\Blog.mdf") +
                   ";Integrated Security=True";
        // 使用聚合函數建立查詢文章數的SQL指令
        // 開啟資料庫連接
        // 建立Command物件的SQL指令

        // 使用ExecuteScalar執行SQL指令
        // 關閉資料庫連接
        return result;
    }
}