﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.PreviousPage != null)
        {
            if (Page.PreviousPage.IsCrossPagePostBack)
            {
                // 宣告物件
                TextBox tName = ((TextBox) PreviousPage.FindControl("tName"));
                TextBox tEmail = ((TextBox) PreviousPage.FindControl("tEmail"));
                CheckBoxList cbDays = ((CheckBoxList) PreviousPage.FindControl("cbDays"));
                DropDownList dHotel = ((DropDownList) PreviousPage.FindControl("dHotel"));
                RadioButtonList rbRoomType = ((RadioButtonList) PreviousPage.FindControl("rbRoomType"));

                // 宣告變數
                int sum, error = 0;
                int[] price = new int[2];

                // 檢查是否有填寫姓名及電子郵件及勾選入住天數
                if (tName.Text.Equals(""))
                {
                    error += 1;
                }
                if (tEmail.Text.Equals(""))
                {
                    error += 2;
                }
                if (cbDays.SelectedIndex == -1)
                {
                    error += 4;
                }
                if (error > 0)
                {
                    Response.Redirect("WebForm3.aspx?error=" + error.ToString());
                }
                           
                // 計算總價
                switch (dHotel.SelectedValue)
                {
                    case "0":
                        price[0] = 2850;
                        price[1] = 3150;
                        sum = calSum(Convert.ToInt32(rbRoomType.SelectedValue), price, 1.1, cbDays);
                        break;
                    case "1":
                        price[0] = 2450;
                        price[1] = 2650;
                        sum = calSum(Convert.ToInt32(rbRoomType.SelectedValue), price, 1.09, cbDays);
                        break;
                    case "2":
                        price[0] = 3950;
                        price[1] = 4250;
                        sum = calSum(Convert.ToInt32(rbRoomType.SelectedValue), price, 1.12, cbDays);
                        break;
                    default:
                        sum = 0;
                        break;
                }

                // 顯示資料
                lblName.Text = ((TextBox) PreviousPage.FindControl("tName")).Text;
                lblHotel.Text = dHotel.SelectedItem.Text;
                lblRoomType.Text = rbRoomType.SelectedItem.Text;
                lblTotal.Text = sum.ToString();
                // 處理入住天數
                for (int i = 0; i < cbDays.Items.Count; i++)
                {
                    if (cbDays.Items[i].Selected)
                    {
                        lblDays.Text = lblDays.Text + cbDays.Items[i].Text + " ";
                    }
                }
            }
            else
            {
                Response.Redirect("WebForm3.aspx?error=7");
            }
        }
        else
        {
            Response.Redirect("WebForm3.aspx?error=7");
        }
    }

    protected int calSum(int roomType, int[] price, double plus, CheckBoxList cbDays)
    {
        int result = 0;

        for (int i = 0; i < cbDays.Items.Count; i++)
        {
            if (cbDays.Items[i].Selected)
            {
                if (cbDays.Items[i].Text == "星期五" || cbDays.Items[i].Text == "星期六")
                {
                    result += (int) (price[roomType] * plus);
                }
                else
                {
                    result += price[roomType];
                }
            }       
        }

        return result;
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm1.aspx");
    }
}