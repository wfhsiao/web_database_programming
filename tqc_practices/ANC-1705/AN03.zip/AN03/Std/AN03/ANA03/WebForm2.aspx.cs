﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void DBInit(string field, string keyword)
    {
        // 根據傳進來的參數來做處理
        switch (field)
        {
            case "Book_Name": // 查詢的欄位是書名
                SqlDataSource1.SelectCommand = "SELECT[Id], [Book_Name], [Publisher], [Author] FROM[Book] WHERE(([Book_Name] LIKE N'%' + @Book_Name + '%'))";
                SqlDataSource1.SelectParameters[0].DefaultValue = keyword;
                break;
            case "Author":  // 查詢的欄位是作者
                SqlDataSource1.SelectCommand = "SELECT[Id], [Book_Name], [Publisher], [Author] FROM[Book] WHERE(([Author] LIKE N'%' + @Author + '%'))";
                SqlDataSource1.SelectParameters[1].DefaultValue = keyword;
                break;
            case "Publisher":  // 查詢的欄位是出版者
                SqlDataSource1.SelectCommand = "SELECT[Id], [Book_Name], [Publisher], [Author] FROM[Book] WHERE(([Publisher] LIKE N'%' + @Publisher + '%'))";
                SqlDataSource1.SelectParameters[2].DefaultValue = keyword;
                break;
            default:  // 沒選查詢欄位
                SqlDataSource1.SelectCommand = "";
                break;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) // 當網頁沒執行PostBack時
        {
            if (PreviousPage != null)  // 檢查觸發PostBack的前頁物件
            {
                if (PreviousPage.IsCrossPagePostBack) // 檢查是不是由WebForm1.aspx觸發PostBack
                {
                    // 使用ViewState儲存相關資料
                    ViewState["field"] = ((DropDownList) PreviousPage.FindControl("dropField")).SelectedValue;
                    ViewState["keyword"] = ((TextBox) PreviousPage.FindControl("keyword")).Text;
                    // 呼叫副程式來處理GridView控制項的資料
                    DBInit(ViewState["field"].ToString(), ViewState["keyword"].ToString());
                }
                else
                {
                    // 當不是的時候移至WebForm1.aspx
                    Response.Redirect("WebForm1.aspx");
                }
            }
            else
            {
                // 當沒有前頁物件時，移至WebForm1.aspx
                Response.Redirect("WebForm1.aspx");
            }
        }
    }

    protected void result_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // 當換頁的時候做的事情

        // 顯示目前正在第幾頁，由於e.NewPageIndex從0開始，故而+1
        lblPage.Text = "，目前顯示第 <font color='blue'>" + (e.NewPageIndex + 1).ToString() + "</font> 頁";
        // 設定GridView控制項應顯示第幾頁
        result.PageIndex = e.NewPageIndex;
        // 呼叫副程式處理資料        
        DBInit(ViewState["field"].ToString(), ViewState["keyword"].ToString());
    }

    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        // SqlDataSource控制項從資料庫執行命令後，需要做的事情

        // 如果影響的列數為0，把顯示目前頁數的控制項文字設為空
        if (e.AffectedRows == 0)
        {
            lblPage.Text = "";
        }

        // 如果ViewState不為空，則根據查詢欄位來顯示總筆數
        if (ViewState["field"] != null && ViewState["keyword"] != null)
        {
            switch (ViewState["field"].ToString())
            {
                case "Book_Name": // 查詢欄位是書名
                    lblMsg.Text = "書名包含\"<font color='red'>" + ViewState["keyword"].ToString() + "</font>\"共有 <font color='blue'>" + e.AffectedRows.ToString() + "</font> 筆紀錄";
                    break;
                case "Author":  // 查詢欄位是作者
                    lblMsg.Text = "作者包含\"<font color='red'>" + ViewState["keyword"].ToString() + "</font>\"共有 <font color='blue'>" + e.AffectedRows.ToString() + "</font> 筆紀錄";
                    break;
                case "Publisher":  // 查詢欄位是出版者
                    lblMsg.Text = "出版者包含\"<font color='red'>" + ViewState["keyword"].ToString() + "</font>\"共有 <font color='blue'>" + e.AffectedRows.ToString() + "</font> 筆紀錄";
                    break;
                default:  // 沒選查詢欄位
                    break;
            }
        }
    }
}