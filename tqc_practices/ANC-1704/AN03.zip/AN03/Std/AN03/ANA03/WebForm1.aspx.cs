﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None; // 設定驗證控制項使用傳統驗證方法
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        // TODO: 將賀卡資料寫入資料庫
        // 宣告並指定新增資料的SQL命令
        string sqlInsert = "INSERT INTO PostCard (Sender, SenderEmail, Message, Receiver, ReceiverEmail, ImageFile) VALUES (N'" +
            sender1.Text + "', N'" + senderEmail.Text + "', N'" + message.Text + "', N'" +
            receiver.Text + "', N'" + receiverEmail.Text + "', '";

        // 處理所選擇的圖片並加入到命令中
        if (rb1.Checked)
        {
            sqlInsert = sqlInsert + "img01.gif');";
        }
        else if (rb2.Checked)
        {
            sqlInsert = sqlInsert + "img02.gif');";
        }
        else if (rb3.Checked)
        {
            sqlInsert = sqlInsert + "img03.gif');";
        }
        else if (rb4.Checked)
        {
            sqlInsert = sqlInsert + "img04.gif');";
        }
        
        // 寫入資料庫
        try
        {
            using (SqlConnection sqlConn =
                 new SqlConnection(WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
            {
                sqlConn.Open();  // 開啟資料庫連線

                SqlCommand sqlCmd = new SqlCommand(sqlInsert, sqlConn);
                try
                {
                    // 新增資料，如果執行命令後受影響列數=0，則傳回錯誤
                    if (sqlCmd.ExecuteNonQuery() == 0)
                    {
                        lblError.Text = "新增賀卡資料有誤，請檢查SQL命令是否有問題";
                        return;
                    }
                                            
                }
                catch (Exception)
                {
                    // 錯誤處理
                    lblError.Text = "新增賀卡資料有誤，請檢查資料庫連接或SQL命令是否有問題";
                    return;
                }

                // 釋放物件
                sqlCmd.Cancel();                
            }
        }
        catch (Exception)
        {
            // 錯誤處理
            lblError.Text = "新增賀卡資料有誤，請檢查資料庫連接或SQL命令是否有問題";
            return;
        }

        // 轉向到WebForm2.aspx
        Response.Redirect("WebForm2.aspx");
    }
}