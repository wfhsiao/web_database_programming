﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int error; // 存放各項錯誤值

        // 擷取傳送過來的資料並存放到對應的變數中
        // 並處理相關的錯誤訊息        
        try
        {
            error = Convert.ToInt32(Request.QueryString["error"]);
            switch (error)
            {
                case 0:
                    break;
                case 1:
                    lblName.Visible = true;
                    msg1.Visible = true;
                    break;
                case 2:
                    lblEmail.Visible = true;
                    msg1.Visible = true;
                    break;
                case 3:
                    lblName.Visible = true;
                    lblAnd.Visible = true;
                    lblEmail.Visible = true;
                    msg1.Visible = true;
                    break;
                case 4:
                    lblDays.Visible = true;
                    break;
                case 5:
                    lblName.Visible = true;
                    msg1.Visible = true;
                    lblDays.Visible = true;
                    break;
                case 6:
                    lblEmail.Visible = true;
                    msg1.Visible = true;
                    lblDays.Visible = true;
                    break;
                case 7:
                    lblName.Visible = true;
                    lblAnd.Visible = true;
                    lblEmail.Visible = true;
                    msg1.Visible = true;
                    lblDays.Visible = true;
                    break;
                default:
                    lblName.Visible = true;
                    lblAnd.Visible = true;
                    lblEmail.Visible = true;
                    msg1.Visible = true;
                    lblDays.Visible = true;
                    break;
            }
        }
        catch
        {
            lblName.Visible = true;
            lblAnd.Visible = true;
            lblEmail.Visible = true;
            msg1.Visible = true;
            lblDays.Visible = true;
        }
    }


    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("WebForm1.aspx");
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
        Response.Redirect("WebForm1.aspx");
    }
}